# 可运行源码交付

本包为适配附件大小，省去可以重新生成的dist和offline-preview，不删除或改动源代码、配置、公共素材、物料、源输入或绑定。

进入本包根目录先执行RUN.md中的npm install、npm run build、npm test，然后npm run demo。build生成dist后才启动网站。需要六页离线HTML，另外执行npm run preview:offline。同路由状态检查执行npm run test:frontend；其结果不等同真实浏览器验收。

完整Word/SVG/PNG/社媒文案和source-input（唯一来源的追溯快照）已包含。原PDF、横幅及地图字节保留；使用通用模板脚本和XLSX重新生成时，public素材和机器binding都从source-input提供。
